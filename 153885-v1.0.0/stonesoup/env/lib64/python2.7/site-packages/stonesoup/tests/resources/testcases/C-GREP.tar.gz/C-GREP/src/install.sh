#!/bin/bash
CC=$1
export
./configure --prefix="$SS_TC_ROOT/$SS_TC_INSTALL" --exec-prefix="$SS_TC_ROOT/$SS_TC_INSTALL"
if [ -n "$CC" ]
then
        make CC="$CC" --keep-going
else
        make install
fi


