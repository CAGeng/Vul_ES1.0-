# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

import os

def which(program) :
    path, executable = os.path.split(program)
    if path :
        if os.path.isfile(program) and os.access(program, os.X_OK) :
            return program
    else :
        for search_path in os.environ['PATH'].split(os.pathsep) :
            search_path = search_path.strip('"')
            search_program = os.path.join(search_path, executable)
            if os.path.isfile(search_program) and os.access(search_program, os.X_OK) :
                return search_program
    return None
    
def get_extension(filename) :
    extension = ''
    path_parts = os.path.splitext(filename)
    while path_parts[1] != '' :
        extension = '%s%s' % (path_parts[1], extension)
        path_parts = os.path.splitext(path_parts[0])
    return extension