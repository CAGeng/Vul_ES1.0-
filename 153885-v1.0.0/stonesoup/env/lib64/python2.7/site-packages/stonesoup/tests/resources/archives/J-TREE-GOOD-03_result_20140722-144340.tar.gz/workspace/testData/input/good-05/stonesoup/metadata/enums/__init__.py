# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

from mapspec import MapSpec
from enum import Enum

CACHE = { }

def get_metadata_enums(module_name):
    '''
    Loads the module for the requested spec version.
    
    version (string): 2.0.1, ...
    
    Returns a module containing MapSpec instances.  This enables modifiable enum encoding.      
    '''
    result = {}
    
    #get the version name
    if module_name is None or len(module_name) == 0 :
        raise ValueError('metadata enum module not specified.')
    
    if module_name in CACHE :
        return CACHE[module_name]
    
    import inspect
    
    #first get the defaults
    defaults_path = 'stonesoup.stew.metadata.enums.%s' % 'default'
    __import__(defaults_path)
    import sys
    defaults_mod = sys.modules[defaults_path]
    del sys
    defaults = inspect.getmembers(defaults_mod, is_mapspec_instance)
    for default in defaults :
        result[default[1].name] = Enum(default[1])
    
    #get the overrides
    overrides_path = 'stonesoup.stew.metadata.enums.%s' % module_name
    __import__(overrides_path)
    import sys
    overrides_mod = sys.modules[overrides_path]
    del sys
    overrides = inspect.getmembers(overrides_mod, is_mapspec_instance)
    for override in overrides :
        result[override[1].name] = Enum(override[1])
    
    del inspect
    CACHE[module_name] = result
    return result

def is_mapspec_instance(object) :
    if object is None :
        return False
    
    return isinstance(object, MapSpec)