# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------


import os
import  argparse, sys
from stonesoup.stew.metadata import get_metadata
import stonesoup.utils.system

class LogFilePostProcessFixer() :
    def __init__(self,
                 version,
                 filename,
                 args) :
        self._metadata_version = get_metadata(version)
        self._args = args
        
        if filename is None :
            raise ValueError('Must provide a valid xml file.')
            
        filename = os.path.abspath(os.path.normpath(filename))
        if filename is None or len(filename) == 0 :
            raise ValueError('Must provide a valid xml file.')
        
        filename = filename.rstrip('/')
        
        if not os.path.isfile(filename) :
            raise ValueError('Must provide a valid xml file.')
            
        self._filename = filename
    
    def __load_metadata(self, filename) :
        metadata = self._metadata_version.project
        metadata.unmarshall(filename)
        return metadata
    
    def run(self):
        metadata = self.__load_metadata(self._filename)
        print self._filename
        print metadata.name
        
        iopairs = metadata.io_pairs
        for iopair in iopairs:
            for post_proc in iopair.inputs_post_processes:
            
                try: 
                    #Handles C-C190, C-C191, and C-C196
                    if post_proc["name"] == 'bash -c \'printf "evaluating input: repeated $(/bin/grep """evaluating input""" $SS_TC_ROOT/testData/logfile.txt | wc -l) times\n$(/bin/grep """finished evaluating""" $SS_TC_ROOT/testData/logfile.txt)\n" | tee $SS_TC_ROOT/testData/logfile.txt\'' :
                        post_proc["name"] = 'bash -c \'printf "evaluating input: repeated $(/bin/grep """evaluating input""" $SS_TC_ROOT/testData/logfile.txt | wc -l) times\n$(/bin/grep """finished evaluating""" $SS_TC_ROOT/testData/logfile.txt)\n" | tee $SS_TC_ROOT/testData/logfile2.txt\''
                        iopair.add_input_parameter(stage='post_process',
                                            source='script_input',
                                            name='sleep 2 && mv -f $SS_TC_ROOT/testData/logfile2.txt $SS_TC_ROOT/testData/logfile.txt')
                                            
                    #Handles J-C190                   
                    if post_proc["name"] == 'bash -c \'grep -vE "^Loop \\# \\-[0-9]+$" ../testData/tc_stderr > ../testData/tc_stderr && printf "Cleaned tc_stderr.\\n"\'' :
                        post_proc["name"] = 'bash -c \'grep -vE "^Loop \\# \\-[0-9]+$" ../testData/tc_stderr > ../testData/tc_stderr_tmp && printf "Cleaned tc_stderr.\\n"\'' 
                        iopair.add_input_parameter(stage='post_process',
                                            source='script_input',
                                            name='sleep 2 && mv -f $SS_TC_ROOT/testData/tc_stderr_tmp $SS_TC_ROOT/testData/tc_stderr')                 
                    
                    #Handles J-C191
                    if post_proc["name"] == 'bash -c \'grep -vE "^some_value\\[\\-20\\] : 20$" ../testData/tc_stderr > ../testData/tc_stderr && printf "Cleaned tc_stderr.\\n"\'':
                        post_proc["name"] = 'bash -c \'grep -vE "^some_value\\[\\-20\\] : 20$" ../testData/tc_stderr > ../testData/tc_stderr_tmp && printf "Cleaned tc_stderr.\\n"\''
                        iopair.add_input_parameter(stage='post_process',
                                            source='script_input',
                                            name='sleep 2 && mv -f $SS_TC_ROOT/testData/tc_stderr_tmp $SS_TC_ROOT/testData/tc_stderr')  
                    
                    #Handles J-C195
                    if post_proc["name"] == 'bash -c \'grep -vE "^Counter Value: [0-9]+$" ../testData/tc_stderr > ../testData/tc_stderr && printf "Cleaned tc_stderr.\\n"\'':
                        post_proc["name"] = 'bash -c \'grep -vE "^Counter Value: [0-9]+$" ../testData/tc_stderr > ../testData/tc_stderr_tmp && printf "Cleaned tc_stderr.\\n"\''
                        iopair.add_input_parameter(stage='post_process',
                                            source='script_input',
                                            name='sleep 2 && mv -f $SS_TC_ROOT/testData/tc_stderr_tmp $SS_TC_ROOT/testData/tc_stderr')  
                    
                    #Handles J-C196
                    if post_proc["name"] == 'bash -c \'grep -vE "^Counter Value: 2$" ../testData/tc_stderr > ../testData/tc_stderr && printf "Cleaned tc_stderr.\\n"\'':
                        post_proc["name"] = 'bash -c \'grep -vE "^Counter Value: 2$" ../testData/tc_stderr > ../testData/tc_stderr_tmp && printf "Cleaned tc_stderr.\\n"\''
                        iopair.add_input_parameter(stage='post_process',
                                            source='script_input',
                                            name='sleep 2 && mv -f $SS_TC_ROOT/testData/tc_stderr_tmp $SS_TC_ROOT/testData/tc_stderr')     
                    
                except:
                    print sys.exc_info()[0]
                    print sys.exc_info()[1]
                    
        # Marshall the fixed metadata back out.
        metadata.marshall(self._filename)
    
def main() :
    # Create Argument Parser
    #######################################################
    parser = argparse.ArgumentParser(prog='fixLogFilePostProcess', fromfile_prefix_chars='@')
    # Add the arguments
    parser.add_argument('-v', '--version', dest='version', required=True,
        help='STEW Metadata Version')
    parser.add_argument('-i', '--infile', dest='testcases', required=True,
        nargs='+', help="identifier for testcases")


    #######################################################
    # Parse the args
    #######################################################
    args = parser.parse_args()
    
    
    for testcase in args.testcases :
        try :
            builder = LogFilePostProcessFixer(args.version, testcase, args) 
            builder.run()
        except :
            raise

if __name__ == '__main__' :
    main()