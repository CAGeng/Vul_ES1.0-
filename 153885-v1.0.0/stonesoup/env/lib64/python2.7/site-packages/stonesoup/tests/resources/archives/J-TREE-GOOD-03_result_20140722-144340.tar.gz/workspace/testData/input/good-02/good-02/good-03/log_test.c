#include <stdio.h>
#include <stdlib.h>
void test_func();

int main(int argc,char **argv)
{
  int x = 0;
  for (int i = 0; i < 4; i++) {
    x = x + 1;
  }
  test_func();
  return 0;
  int temp = 2;
}

void test_func()
{
  int y = 5;
  y += 1;
}
