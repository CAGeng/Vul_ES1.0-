# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

class LowerDict(dict) :
    def __init__(self, *args, **kwargs) :
        self.update(*args, **kwargs)
        
    def __keytransform__(self, key) :
        return str(key).lower()
    
    def __getitem__(self, key) :
        return super(LowerDict, self).__getitem__(self.__keytransform__(key))
    
    def __setitem__(self, key, value) :
        return super(LowerDict, self).__setitem__(self.__keytransform__(key), value)
    
    def __delitem__(self, key) :
        return super(LowerDict, self).__delitem__(self.__keytransform__(key))
    
    def __contains__(self, key) :
        return super(LowerDict, self).__contains__(self.__keytransform__(key))
    
    def __handle_arg__(self, arg) :
        trans = self.__keytransform__
        if isinstance(arg, LowerDict) :
            return arg
        elif isinstance(arg, dict) :
            return dict( (trans(k), v) for k, v in arg.iteritems() )
        else :
            args_trans = [ ]
            for element in arg :
                if len(element) != 2 :
                    raise ValueError('LowerDict update sequence element #%d has length %d; 2 is required' % (len(args_trans), len(element)))
                args_trans.append((trans(element[0]), element[1]))
            return args_trans
    
    def update(self, *args, **kwargs) :
        trans = self.__keytransform__
        if len(args) > 1 :
            raise TypeError('LowerDict expected at most 1 argument, got %d' % len(args))
        elif len(args) == 1 :
            super(LowerDict, self).update(*[self.__handle_arg__(x) for x in args], 
                **dict((trans(k), kwargs[k]) for k in kwargs))
        else :
            super(LowerDict, self).update(*args, 
                **dict((trans(k), kwargs[k]) for k in kwargs))