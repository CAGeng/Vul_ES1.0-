#include <stdlib.h>
#include <string.h>

int main(){
	
	char * value=0;
	int size=0;
	char * buffer=0;
	value=getenv("ENVVARIABLE");
	size=atoi(value);
	buffer=malloc(size);
	memset(buffer,'A',size-1);
	buffer[size]='\0';	
}

