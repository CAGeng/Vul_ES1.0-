# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

# generateDS -o stonesoup/stew/metadata/specs/2_1_0.py --root-element=project --super=2_1_0 STEW_2_1_0.xsd

def get_metadata_spec(module_name):
    '''
    Loads the module for the requested spec version.
    
    version (string): 2.0.1, ...
    
    Returns a generateDS API for the XSD.      
    '''
    if module_name is None or len(module_name) == 0 :
        raise ValueError('metadata spec module not specified.')
    
    path = 'stonesoup.stew.metadata.specs.%s' % module_name
    __import__(path)
    import sys
    result = sys.modules[path]
    del sys
    
    return result