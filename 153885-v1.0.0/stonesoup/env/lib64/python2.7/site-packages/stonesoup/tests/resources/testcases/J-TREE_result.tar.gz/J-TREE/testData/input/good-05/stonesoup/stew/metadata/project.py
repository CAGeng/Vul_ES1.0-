# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

import itertools
import re

from stonesoup.stew.metadata.specs import get_metadata_spec
from stonesoup.stew.metadata.enums import get_metadata_enums

from stonesoup.stew.metadata.enums import Enum

# compile schemas
#generateDS -o stonesoup/stew/metadata/specs/2_0_1.py --root-element=project --super=stonesoup.stew.metadata.2_0_1 ../CompleteMetaData-for-STEW-v2.0.1.xsd

class BaseProject(object) :
    def __init__(self, version, metadata_spec, metadata_enums, io_pair_handler, metadata=None) :
        '''
        Initializes the interface by loading the spec of the requested version.
        '''
        self.__version = version
        self._spec = metadata_spec
        self.__enums = metadata_enums
        self._io_pair_handler = io_pair_handler
        
        self._enum_code_complexity_types = self.enums['code_complexity_feature_groups']
        self._enum_code_complexity_source_taints = self.enums['code_complexity_source_taint_features']
        self._enum_code_complexity_data_types = self.enums['code_complexity_data_type_features']
        self._enum_code_complexity_data_flows = self.enums['code_complexity_data_flow_features']
        self._enum_code_complexity_control_flows = self.enums['code_complexity_control_flow_features']
        
        self._enum_generation_methods = self.enums['generation_methods']
        self._enum_languages = self.enums['language_types']
        self._enum_language_classes = self.enums['language_class_types']
        self._enum_architectures = self.enums['architecture_types']
        self._enum_project_levels = self.enums['project_level_types']
        self._enum_platforms = self.enums['platforms']
        self._enum_entry_points = self.enums['entry_point_types']
        
        self._re_weakness_code = re.compile('^[A-Z]{3}-[0-9]{1,3}$')
        
        if self.__version is None or len(self.__version) == 0 :
            raise ValueError('version not specified.')
        
        # load info (incase we are not starting from scratch)
        if metadata is not None :
            #unmarshall previous metadata
            self.unmarshall(metadata)
        else :
            #create new metadata
            self._project = self._spec.project()
            self._build_commands = self._load_build_commands()
            self._code_complexity_features = self._load_code_complexity_features()
            self._weakness_code, self._weakness_entry_points =\
                self._load_target_weakness()
            self._test_cases = self._load_test_cases()
            self._io_pairs = self._load_io_pairs()
        return
    
    @property
    def enums(self) :
        return self.__enums
    
    @property
    def version(self) :
        return self.__version
    
    @property
    def name(self) :
        return self._project.get_name()
    
    @name.setter
    def name(self, value) :
        self._project.set_name(value)
    
    @property
    def run_command(self) :
        return self._project.get_run_command()
    
    @run_command.setter
    def run_command(self, value) :
        self._project.set_run_command(value)
    
    @property
    def description(self) :
        return self._project.get_description()
    
    @description.setter
    def description(self, value) :
        self._project.set_description(value)
    
    @property
    def line_count(self) :
        return self._project.get_line_count()
    
    @line_count.setter
    def line_count(self, value) :
        self._project.set_line_count(value)
    
    @property
    def display_name(self) :
        return self._project.get_display_name()
    
    @display_name.setter
    def display_name(self, value) :
        self._project.set_display_name(value)
    
    @property
    def timeout_execute(self) :
        return self._project.get_timeout_execute()
    
    @timeout_execute.setter
    def timeout_execute(self, value) :
        self._project.set_timeout_execute(value)
    
    @property
    def run_directory(self) :
        return self._project.get_run_directory()
    
    @run_directory.setter
    def run_directory(self, value) :
        self._project.set_run_directory(value)
    
    @property
    def build_directory(self) :
        return self._project.get_build_directory()
    
    @build_directory.setter
    def build_directory(self, value) :
        self._project.set_build_directory(value)
    
    @property
    def src_directory(self) :
        return self._project.get_src_directory()
    
    @src_directory.setter
    def src_directory(self, value) :
        self._project.set_src_directory(value)
    
    @property
    def install_directory(self) :
        return self._project.get_install_directory()
    
    @install_directory.setter
    def install_directory(self, value) :
        self._project.set_install_directory(value)
    
    @property
    def bin_exe_directory(self) :
        return self._project.get_bin_exe_directory()
    
    @bin_exe_directory.setter
    def bin_exe_directory(self, value) :
        self._project.set_bin_exe_directory(value)
    
    @property
    def runnable_name(self) :
        return self._project.get_runnable_name()
    
    @runnable_name.setter
    def runnable_name(self, value) :
        self._project.set_runnable_name(value)
    
    @property
    def library_directory(self) :
        return self._project.get_library_directory()
    
    @library_directory.setter
    def library_directory(self, value) :
        self._project.set_library_directory(value)
    
    @property
    def script_directory(self) :
        return self._project.get_script_directory()
    
    @script_directory.setter
    def script_directory(self, value) :
        self._project.set_script_directory(value)
    
    @property
    def generation_method(self) :
        return self._project.get_generation_method()
    
    @generation_method.setter
    def generation_method(self, value) :
        if value is not None and\
                not self._enum_generation_methods.is_valid(value) :
            raise ValueError('generation method is not supported.')
        self._project.set_generation_method(self._marshall_enum(value,
            self._enum_generation_methods))
    
    @property
    def language(self) :
        return self._project.get_language()
    
    @language.setter
    def language(self, value) :
        if value is not None and\
                not self._enum_languages.is_valid(value) :
            raise ValueError('language is not supported.')
        self._project.set_language(self._marshall_enum(value,
            self._enum_languages))
    
    @property
    def architecture(self) :
        return self._project.get_architecture()
    
    @architecture.setter
    def architecture(self, value) :
        if value is not None and\
                not self._enum_architectures.is_valid(value) :
            raise ValueError('architecture is not supported.')
        self._project.set_architecture(self._marshall_enum(value,
            self._enum_architectures))
    
    @property
    def derived_from_project_name(self) :
        return self._project.get_derived_from_project_name()
    
    @derived_from_project_name.setter
    def derived_from_project_name(self, value) :
        self._project.set_derived_from_project_name(value)
    
    @property
    def project_level(self) :
        return self._project.get_project_level()
    
    @project_level.setter
    def project_level(self, value) :
        if value is not None and\
                not self._enum_project_levels.is_valid(value) :
            raise ValueError('project level is not supported.')
        self._project.set_project_level(self._marshall_enum(value,
            self._enum_project_levels))
    
    @property
    def build_commands(self) :
        return self._build_commands
    
    @build_commands.setter
    def build_commands(self, value) :
        if isinstance(value, list) :
            self._build_commands = value
        elif isinstance(value, tuple) :
            self._build_commands = list(value)
        else :
            raise TypeError
            
    @property
    def code_complexity_features(self) :
        return self._code_complexity_features
        
    def add_code_complexity_feature(self,
                                    file_name=None, 
                                    function_name=None,
                                    line_number=None,
                                    feature_group=None,
                                    feature=None) :
        enc_line_number = None
        if isinstance(line_number, str) :
            enc_line_number = int(line_number)
        elif isinstance(line_number, int) :
            enc_line_number = line_number
        else :
            raise TypeError('line_number must be an int() or str().')
            
        if feature_group is not None and\
                not self._enum_code_complexity_types.is_valid(feature_group) :
            raise ValueError('feature group is not supported.')
        if feature is not None :
            if not self._enum_code_complexity_source_taints.is_valid(feature) and\
                    not self._enum_code_complexity_data_types.is_valid(feature) and\
                    not self._enum_code_complexity_data_flows.is_valid(feature) and\
                    not self._enum_code_complexity_control_flows.is_valid(feature) :
                raise ValueError('feature is not supported.')
        
        code_complexity_feature = { 'file_name': file_name,
                                    'function_name': function_name, 
                                    'line_number': enc_line_number, 
                                    'feature_group': self._marshall_enum(feature_group,
                                        self._enum_code_complexity_types), 
                                    'feature': self._marshall_enum(feature,
                                        (self._enum_code_complexity_source_taints,
                                         self._enum_code_complexity_data_types,
                                         self._enum_code_complexity_data_flows,
                                         self._enum_code_complexity_control_flows)) }
        
        self._code_complexity_features.append(code_complexity_feature)
        
        return code_complexity_feature
    
    @property
    def weakness_code(self) :
        return self._weakness_code
        
    @weakness_code.setter
    def weakness_code(self, value) :
        if value is not None and\
                self._re_weakness_code.match(value) is None :
            raise ValueError('weakness code not supported.')
        self._weakness_code = value
    
    @property
    def weakness_entry_points(self) :
        return self._weakness_entry_points
        
    def add_weakness_entry_point(self,
                                 file_name=None, 
                                 function_name=None,
                                 line_number=None,
                                 entry_point_type=None) :
        enc_line_number = None
        if isinstance(line_number, str) :
            enc_line_number = int(line_number)
        elif isinstance(line_number, int) :
            enc_line_number = line_number
        else :
            raise TypeError('line_number must be an int() or str().')
            
        if entry_point_type is not None and\
                not self._enum_entry_points.is_valid(entry_point_type) :
            raise ValueError('entry point type not supported.')
        
        weakness_entry_point = { 'file_name': file_name,
                                 'function_name': function_name, 
                                 'line_number': enc_line_number, 
                                 'entry_point_type': self._marshall_enum(entry_point_type,
                                        self._enum_entry_points) }
        
        self._weakness_entry_points.append(weakness_entry_point)
        
        return weakness_entry_point
    
    @property
    def test_cases(self) :
        return self._test_cases
        
    def add_test_case(self,
                      name=None, 
                      description=None,
                      timeout=None,
                      language_class=None) :
        enc_timeout_execute = None
        if timeout is not None :
            if isinstance(timeout, str) :
                enc_timeout_execute = int(timeout)
            elif isinstance(timeout, int) :
                enc_timeout_execute = timeout
            else :
                raise TypeError('timeout must be an int() or str().')
            
        if language_class is not None and\
                not self._enum_language_classes.is_valid(language_class) :
            raise ValueError('language class not supported.')
        
        test_case = { 'name': name,
                      'description': description, 
                      'timeout_execute': enc_timeout_execute, 
                      'language_class': self._marshall_enum(language_class,
                            self._enum_language_classes) }
        
        self._test_cases.append(test_case)
        
        return test_case
        
    @property
    def io_pairs(self) :
        return self._io_pairs
    
    def new_io_pair(self) :
        return self._io_pair_handler(version=self.__version, 
                metadata_spec=self._spec,
                metadata_enums=self.__enums)
    
    def rename(self, new_name) :
        self.name = new_name
        self.display_name = new_name
        
        for test_case in self.test_cases :
            test_case['name'] = '%s-TC-%s' % (new_name, test_case['language_class'].upper())
        
        counts = { }
        for io_pair in self.io_pairs :
            count = counts.setdefault(io_pair.category, 1)
            io_pair.name = '%s-IO-%s-%02d' % (new_name, io_pair.category.upper(), count)
            counts[io_pair.category] = count + 1
    
    def marshall(self, outfile) :
        self._update_build_commands()
        self._update_code_complexity_features()
        self._update_target_weakness()
        self._update_test_cases()
        self._update_io_pairs()
    
        if isinstance(outfile, str) :
            with open(outfile, mode='w') as outstream :
                outstream.write('<?xml version="1.0" encoding="UTF-8" ?>\n')
                self._project.export(outstream, 0)
        else :
            outfile.write('<?xml version="1.0" encoding="UTF-8" ?>\n')
            self._project.export(outfile, 0)
    
        return
    
    def unmarshall(self, infile) :
        document = None
        if isinstance(infile, str) :
            with open(infile, mode='r') as instream :
                document = self._spec.parsexml_(instream)
        else :
            document = self._spec.parsexml_(infile)
        
        if document is None :
            raise RuntimeError('metadata file could not be parsed.')
        
        project = self._spec.project.factory()
        project.build(document.getroot())
        document = None
        
        #sync everything
        self._project = project
        self._build_commands = self._load_build_commands()
        self._code_complexity_features = self._load_code_complexity_features()
        self._weakness_code, self._weakness_entry_points =\
            self._load_target_weakness()
        self._test_cases = self._load_test_cases()
        self._io_pairs = self._load_io_pairs()
        return
        
    def _load_build_commands(self) :
        enc_commands = self._project.get_build_commands()
        
        if enc_commands is None :
            return [ ]
        
        enc_commands = enc_commands.get_build_command()
        
        if enc_commands is None or len(enc_commands) == 0 :
            return [ ]
        
        # ensure sorted
        enc_commands.sort(key=lambda command: command.order)
        
        return [build_command.command for build_command in enc_commands]
    
    def _update_build_commands(self) :
        if self._build_commands is None or len(self._build_commands) == 0 :
            self._project.set_build_commands(None)
        else :
            self._project.set_build_commands(
                self._spec.buildCommandsType(build_command=\
                    [ self._spec.buildCommandType(order=index, command=comm)\
                        for index, comm in itertools.izip(itertools.count(1),\
                            self._build_commands) ]))
        return
    
    def _load_code_complexity_features(self) :
        raw_features = [ ]
        enc_features = self._project.get_code_complexity_features()
        
        if enc_features is None :
            return raw_features
            
        enc_features = enc_features.get_code_complexity_feature()
            
        if enc_features is None or len(enc_features) == 0 :
            return raw_features
        
        for enc_feature in enc_features :
            raw_features.append( { 'file_name': enc_feature.get_file_name(),
                                   'function_name': enc_feature.get_function_name(), 
                                   'line_number': enc_feature.get_line_number(), 
                                   'feature_group': enc_feature.get_feature_group(), 
                                   'feature': enc_feature.get_feature() } )
        
        return raw_features
        
    def _update_code_complexity_features(self) :
        if self._code_complexity_features is None or len(self._code_complexity_features) == 0 :
            self._project.set_code_complexity_features(None)
        else :
            self._project.set_code_complexity_features(
                self._spec.ccFeaturesType(code_complexity_feature=\
                    [ self._spec.ccFeatureType.factory(**x)\
                        for x in self._code_complexity_features ]))
        return
    
    def _load_target_weakness(self) :
        raw_weakness_entry_points = [ ]
        
        enc_target_weakness = self._project.get_target_weakness()
        if enc_target_weakness is None :
            return None, raw_weakness_entry_points
        
        enc_weakness_entry_points = enc_target_weakness.get_weakness_entry_points()
        if enc_weakness_entry_points is None :
            return enc_target_weakness.weakness_code, raw_weakness_entry_points
        
        enc_weakness_entry_points = enc_weakness_entry_points.get_weakness_entry_point()
        if enc_weakness_entry_points is None or len(enc_weakness_entry_points) == 0 :
            return enc_target_weakness.weakness_code, raw_weakness_entry_points
        
        for enc_weakness_entry_point in enc_weakness_entry_points :
            raw_weakness_entry_points.append(\
                { 'file_name': enc_weakness_entry_point.get_file_name(),
                  'function_name': enc_weakness_entry_point.get_function_name(), 
                  'line_number': enc_weakness_entry_point.get_line_number(), 
                  'entry_point_type': enc_weakness_entry_point.get_entry_point_type() } )
        
        return enc_target_weakness.weakness_code, raw_weakness_entry_points
        
    def _update_target_weakness(self) :
        enc_target_weakness = self._spec.targetWeaknessType(\
            weakness_code=self._weakness_code)
        
        if self._weakness_entry_points is None or len(self._weakness_entry_points) == 0 :
            self._project.set_target_weakness(enc_target_weakness)
        else :
            enc_target_weakness.set_weakness_entry_points(\
                self._spec.weaknessEntryPointsType(weakness_entry_point=\
                    [ self._spec.weaknessEntryPointType.factory(**x)\
                        for x in self._weakness_entry_points ]))
            self._project.set_target_weakness(enc_target_weakness)
        return
        
    def _load_test_cases(self) :
        raw_test_cases = [ ]
        
        enc_test_cases = self._project.get_soup_test_cases()
        if enc_test_cases is None :
            return raw_test_cases
        
        enc_test_cases = enc_test_cases.get_soup_test_case()
        if enc_test_cases is None or len(enc_test_cases) == 0 :
            return raw_test_cases
        
        for enc_test_case in enc_test_cases :
            raw_test_cases.append(\
                { 'name': enc_test_case.get_name(),
                  'description': enc_test_case.get_description(), 
                  'timeout_execute': enc_test_case.get_timeout_execute(), 
                  'language_class': enc_test_case.get_language_class() } )
        
        return raw_test_cases
        
    def _update_test_cases(self) :
        enc_test_cases = self._spec.soupTestCasesType()
        
        if self._test_cases is None or len(self._test_cases) == 0 :
            self._project.set_soup_test_cases(enc_test_cases)
        else :
            enc_test_cases.set_soup_test_case(\
                [ self._spec.testCaseType.factory(**x)\
                    for x in self._test_cases ])
            self._project.set_soup_test_cases(enc_test_cases)
        return
    
    def _load_io_pairs(self) :
        raw_io_pairs = [ ]
        
        enc_io_pairs = self._project.get_io_pairs()
        if enc_io_pairs is None :
            return raw_io_pairs
        
        enc_io_pairs = enc_io_pairs.get_io_pair()
        if enc_io_pairs is None or len(enc_io_pairs) == 0 :
            return raw_io_pairs
        
        for enc_io_pair in enc_io_pairs :
            raw_io_pair = self._io_pair_handler(version=self.__version, 
                metadata_spec=self._spec,
                metadata_enums=self.__enums)
            raw_io_pair.unmarshall(enc_io_pair)
            raw_io_pairs.append(raw_io_pair)
    
        return raw_io_pairs
    
    def _update_io_pairs(self) :
        self._project.set_io_pairs(\
            self._spec.ioPairsType(io_pair=\
                [ x.marshall() for x in self._io_pairs ] ))
        return
    
    def _marshall_enum(self, 
                       value,
                       enum=None) :
        if value is None :
            return None
        
        if enum is None :
            return None
        
        if isinstance(enum, list) or\
                isinstance(enum, tuple) :
            for v in enum :
                if v.is_valid(value) :
                    return v.marshall(value)
        elif isinstance(enum, Enum) :
            return enum.marshall(value)
        
        raise ValueError('failed to marshall enum "%s".' % value)

class StewProject2_0_1(BaseProject) :
    def __init__(self, version, metadata_spec, metadata_enums, io_pair_handler, metadata=None) :
        '''
        Initializes the interface by loading the spec of the requested version.
        '''
        super(StewProject2_0_1, self).__init__(version, 
                                               metadata_spec, 
                                               metadata_enums, 
                                               io_pair_handler, 
                                               metadata)
        return

class StewProject2_1_0(BaseProject) :
    def __init__(self, version, metadata_spec, metadata_enums, io_pair_handler, metadata=None) :
        '''
        Initializes the interface by loading the spec of the requested version.
        '''
        super(StewProject2_1_0, self).__init__(version, 
                                               metadata_spec, 
                                               metadata_enums, 
                                               io_pair_handler, 
                                               metadata)
        
    @property
    def platform(self) :
        return self._project.get_platform()
    
    @platform.setter
    def platform(self, value) :
        if value is not None and\
                not self._enum_platforms.is_valid(value) :
            raise ValueError('platform is not supported.')
        self._project.set_platform(self._marshall_enum(value,
            self._enum_platforms))
        
        return
        
class StewProject5_0_0(StewProject2_1_0) :
    def __init__(self, version, metadata_spec, metadata_enums, io_pair_handler, metadata=None) :
        '''
        Initializes the interface by loading the spec of the requested version.
        '''
        super(StewProject5_0_0, self).__init__(version, 
                                               metadata_spec, 
                                               metadata_enums, 
                                               io_pair_handler, 
                                               metadata)
                                               
        self._enum_resource_limit_types = self.enums['resource_limit_types']
        
        
        # load info (incase we are not starting from scratch)
        if metadata is None :
            self._resource_limits = { }
                                               

    def resource_limit(self, type) :
        return self._resource_limits[self._marshall_enum(type, self._enum_resource_limit_types)]
        
    
    def add_resource_limit(self, type, value) :
        if not self._enum_resource_limit_types.is_valid(type) or not isinstance(value, str) :
            raise ValueError('resource_limit is not supported.')
        
        if self._resource_limits is None  :
            self._resource_limits = { }
        
        self._resource_limits[self._marshall_enum(type, self._enum_resource_limit_types)] = value
            
        return
    
    def marshall(self, outfile) :
        self._update_resource_limits()
        super(StewProject5_0_0, self).marshall(outfile)
        
        return
    
    def unmarshall(self, infile) :
        super(StewProject5_0_0, self).unmarshall(infile)
        self._resource_limits = self._load_resource_limits()
        
        return
        
    def _load_resource_limits(self) :
        
        resource_limits = { }
        
        enc_limit = self._project.get_resource_limit()
        
        if enc_limit is None :
            return None
#         keys = self._enum_resource_limit_types.values()
#         for key in  keys:
#             val = getattr(enc_limit, "get_%s" % self._marshall_enum(key, self._enum_resource_limit_types))
#         
#             if val is not None and len(val) != 0 :
#                 resource_limits[key] = val
        memory = enc_limit.get_memory_limit()
        cpu = enc_limit.get_cpu_limit()
        file_handles = enc_limit.get_file_descriptor_limit()
        process = enc_limit.get_process_limit()
        disk_space = enc_limit.get_disk_space_limit()
        
        if memory is not None:
            resource_limits[self._marshall_enum('memory', self._enum_resource_limit_types)] = memory
        if cpu is not None:
            resource_limits[self._marshall_enum('cpu', self._enum_resource_limit_types)] = cpu
        if file_handles is not None:
            resource_limits[self._marshall_enum('files', self._enum_resource_limit_types)] = file_handles
        if process is not None:
            resource_limits[self._marshall_enum('process', self._enum_resource_limit_types)] = process
        if disk_space is not None:
            resource_limits[self._marshall_enum('disk', self._enum_resource_limit_types)] = disk_space
        return resource_limits
    
    def _update_resource_limits(self) :
        
        if self._resource_limits is None or len(self._resource_limits) == 0 :
            self._project.set_resource_limit(None)
        else :
            self._project.set_resource_limit(
                self._spec.resourceLimitType.factory(**self._resource_limits))
#             keys = self._enum_resource_limit_types.values()
#             for key in keys :
#                 value = self._resource_limits[key]
#                 getattr(self._project.set_resource_limit(), "set_%s" % self._marshall_enum(key, self._enum_resource_limit_types))(value)
#                 
        return