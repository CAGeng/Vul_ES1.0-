#!/bin/sh
tar -xzvf extras.tar.gz

