# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

import re

from stonesoup.stew.metadata.specs import get_metadata_spec
from stonesoup.stew.metadata.enums import get_metadata_enums

from project import StewProject2_0_1, StewProject2_1_0, StewProject5_0_0

from iopair import StewIOPair2_0_1, StewIOPair2_1_0, StewIOPair2_1_1

def cmp_versions(version1, version2):
    """This function compares two version numbers.

    Args:
       version1 (str):  The first version.
       version2 (str):  The second version.

    Returns:
       int.  The comparison::

          0 -- version1 = version2
          -1 -- version1 < version2
          1 -- version1 > version2

    Example::

        result = cmp_version('0.9', '1.0')
        if result < 0 :
            print 'earlier version'
        elif result > 0 :
            print 'later version'
        else :
            print 'same version'
    
    """
    def normalize(v):
        return [int(x) for x in re.sub(r'(\.0+)*$','', v).split(".")]
    return cmp(normalize(version1), normalize(version2))

class MetadataVersion() :
    """This class represents a specific released version of the STEW metadata 
    specification (schema/xsd) from the MITRE team.  In most cases, changes to the
    underlying metadata specification are minimal, such as adding or removing a single
    element.  Thus, this allows the specification to be paired with different wrapper 
    classes for the project and io pairs.  This class provides the :func:project to 
    build new metadata instances and :func:validate to validate a metadata xml document 
    against the schema.

    **NEVER** create an instance of this yourself.

    """
    def __init__(self, 
                 version, 
                 spec_module_name,
                 enum_module_name,
                 project,
                 io_pair) :
        import os
        try :
            import cStringIO as StringIO
        except ImportError :
            import StringIO
        from lxml import etree
            
        self.__version = version
        self.__spec_module_name = spec_module_name
        self.__enum_module_name = enum_module_name
        self.__spec_module = get_metadata_spec(self.__spec_module_name)
        self.__enum_module = get_metadata_enums(self.__enum_module_name)
        self.__project = project
        self.__io_pair = io_pair
        self.__spec_schema_name = os.path.join(\
            os.path.dirname(self.__spec_module.__file__), 
            'metadata_schema_%s.xsd' % self.__spec_module_name)
        self.__spec_schema = None
        with open(self.__spec_schema_name, mode='r') as instream :
            schema_dom_doc = etree.parse(instream)
            self.__spec_schema = etree.XMLSchema(schema_dom_doc)
        
        del etree
        del StringIO
        del os
        return
    
    @property
    def version(self) :
        """Get the version."""
        return self.__version
    
    @property
    def project(self) :
        """This builds a new instance of the project wrapper class designated 
        for this metadata version.  Refer to :module:`stonesoup.stew.metadata.project`
        for definitions of project wrappers for specific project versions.
        
        Returns:
           :class:`stonesoup.stew.metadata.project.BaseProject`.  Subclass instance.

        """
        return self.__project(self.__version, 
            self.__spec_module, 
            self.__enum_module,
            self.__io_pair)
    
    @property
    def schema(self) :
        """This returns the loaded instance of the metadata schema used to validate
        instances of the encoded metadata.  The schema is represented through the 
        :module:`lxml.etree` library.
        
        Returns:
           :class:`lxml.etree.XMLSchema`.  Schema instance.

        """
        return self.__spec_schema
    
    @property
    def schema_name(self) :
        """The schema file name."""
        return self.__spec_schema_name
    
    def validate(self, metadata, ignore_errors=False) :
        """This function validates a metadata file against the loaded schema.
        
        Args:
           metadata (str or filelike):  metadata filename or file stream.
        
        Kwargs:
           ignore_errors (bool)::
           
               True -- Silently fail if not valid
               False -- (DEFAULT) raise on error
        
        Returns:
           bool.  The validation result::
        
              True -- Valid
              False -- Invalid
        
        Raises:
           DocumentInvalid
        
        Example 01::
        
            validate('metadata.xml')
        
        Example 02::
            
            with open('metadata.xml', mode='r') as instream : 
                validate(instream)
        
        """
        from lxml import etree
        document = None
        if isinstance(metadata, str) :
            with open(metadata, mode='r') as instream :
                document = etree.parse(instream)
        else :
            document = etree.parse(metadata)
        
        if ignore_errors :
            return self.schema.validate(document)
        
        self.schema.assertValid(document)
        return True

# This is the list of available versions.  Versions are valid until the next higher version
# number supersedes the previous.  Thus this list is order dependent (OLDER -> NEWER).
AVAILABLE_VERSIONS = [ MetadataVersion('2.0.1', '2_0_1', '2_0_1', StewProject2_0_1, StewIOPair2_0_1),
                       MetadataVersion('2.1.0', '2_1_0', '2_1_0', StewProject2_1_0, StewIOPair2_1_0),
                       MetadataVersion('2.1.1', '2_1_1', '2_1_0', StewProject2_1_0, StewIOPair2_1_1),
                       MetadataVersion('3.0.0', '3_0_0', '2_1_0', StewProject2_1_0, StewIOPair2_1_1),
                       MetadataVersion('5.0.0', '5_0_0', '5_0_0', StewProject5_0_0, StewIOPair2_1_1)  ]

def get_metadata(version) :
    metadata = None
    for installed_version in AVAILABLE_VERSIONS :
        if cmp_versions(installed_version.version, version) < 0 :
            # installed version is older, save and look for newer
            metadata = installed_version
        elif cmp_versions(installed_version.version, version) > 0 :
            # installed version is too new, revert
            return metadata
        else :
            #exact match, use this installed version
            return installed_version