#include <stdio.h>

int main()
{

FILE *pfile;
char mystring[100];
puts("Opening 'myfile.txt' for reading");
pfile=fopen("myfile.txt", "r");
if(pfile!=NULL){
	puts("Reading from file:\n");
	while(fgets(mystring,100,pfile)!=NULL){
		puts(mystring);
	}
	fclose(pfile);
}
else{
	puts("Failed to open file");
}
}
