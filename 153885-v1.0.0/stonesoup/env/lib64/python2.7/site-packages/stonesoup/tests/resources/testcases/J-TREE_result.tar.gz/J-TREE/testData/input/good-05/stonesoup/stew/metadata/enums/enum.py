# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

class Enum(object) :
    def __init__(self, map) :
        self.__map = map
        self.__unmarshall_map = { }
        for key, value in self.__map.map.iteritems() :
            self.__unmarshall_map[value] = key
        return
        
    @property
    def name(self) :
        return self.__map.name
    
    @property
    def values(self) :
        return self.__map.union.viewkeys()
        
    def is_valid(self, value) :
        return value in self.__map.union

    def marshall(self, value) :
        return self.__map.union[value]
    
    def unmarshall(self, value) :
        return self.__unmarshall_map[value]
    
    
    