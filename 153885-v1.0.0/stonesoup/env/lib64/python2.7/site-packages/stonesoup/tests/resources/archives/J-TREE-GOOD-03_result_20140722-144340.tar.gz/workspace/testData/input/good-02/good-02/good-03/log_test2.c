#include <stdio.h>
#include <stdlib.h>
void test_func();

int main(int argc,char **argv)
{
  puts("%s,%s,%d,%d\n","log_test.c","main",5,23);
  int x = 0;

  for (int i = 0; i < 4; i++) {
    x = x + 1;
  }
  test_func();
  return 0;
  int temp = 2;
}

void test_func()
{
  puts("%s,%s,%d,%d\n","log_test.c","test_func",18,24);
  int y = 5;
  y += 1;
}
