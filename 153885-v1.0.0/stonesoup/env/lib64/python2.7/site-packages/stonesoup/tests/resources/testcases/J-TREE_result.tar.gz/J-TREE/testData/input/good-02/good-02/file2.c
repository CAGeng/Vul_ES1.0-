#include <stdio.h>
#include <stdlib.h>

int main(){
	char * buffer=malloc(200*sizeof(char));
	FILE* file=fopen("somefile.txt","r");
	if(file!=NULL){
		fread(buffer,sizeof(char),200,file);
		puts(buffer);
	}
}
