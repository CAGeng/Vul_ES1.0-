# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

from mapspec import MapSpec
from stonesoup.utils.dicts import LowerDict

IO_PAIR_CATEGORIES = MapSpec(\
    name='io_pair_categories', 
    map=LowerDict( { 'GOOD': 1,
                     'BAD': 2 } ),
    aliases=LowerDict( { '1': 1,
                         '2': 2 } ))

IO_INPUT_FEATURES = MapSpec(\
    name='io_input_features', 
    map=LowerDict( { 'STDIN': 3,
                     'COMMAND_LINE': 7,
                     'ENVIRONMENT_VARIABLE': 8,
                     'FILE_CONTENTS': 9,
                     'SHARED_MEMORY': 16 } ),
    aliases=LowerDict( { '3': 3,
                         'COMMANDLINE': 7,
                         'CLI': 7,
                         'ARGS': 7,
                         '7': 7,
                         'ENVIRONMENTVARIABLE': 8,
                         'ENV': 8,
                         'ENVVAR': 8,
                         'EXPORT': 8,
                         'FILECONTENTS': 9,
                         'FILE': 9,
                         'SHAREDMEMORY': 16,
                         'SHAREDMEM': 16,
                         'MEM': 16 } ))

IO_VALUE_TYPES = MapSpec(\
    name='io_value_types', 
    map=LowerDict( { 'USE_TEXT_DIRECTLY': 1,
                     'USE_CONTENTS_OF_FILE': 2 } ),
    aliases=LowerDict( { 'TEXT_DIRECTLY': 1,
                         'TEXT': 1,
                         '1': 1,
                         'CONTENTS_OF_FILE': 2,
                         'FILE': 2,
                         '2': 2 } ))
              
TECHNICAL_IMPACTS = MapSpec(\
    name='technical_impacts', 
    map=LowerDict( { 'NONE': 1,
          'UNSPECIFIED': 2,
          'READ_FILES': 3,
          'READ_APPLICATION_DATA': 4,
          'GAIN_PRIVILEGES': 5,
          'HIDE_ACTIVITIES': 6,
          'EXECUTE_UNAUTHORIZED_CODE': 7,
          'MODIFY_FILES': 8,
          'MODIFY_APPLICATION_DATA': 9,
          'BYPASS_PROTECTION_MECHANISM': 10,
          'ALTER_EXECUTION_LOGIC': 11,
          'UNEXPECTED_STATE': 12,
          'DOS_UNCONTROLLED_EXIT': 13,
          'DOS_AMPLIFICATION': 14,
          'DOS_INSTABILITY': 15,
          'DOS_BLOCKING': 16,
          'DOS_RESOURCE_CONSUMPTION': 17 } ),
    aliases=LowerDict( { '1': 1,
              '2': 2,
              '3': 3,
              '4': 4,
              '5': 5,
              '6': 6,
              '7': 7,
              '8': 8,
              '9': 9,
              '10': 10,
              '11': 11,
              '12': 12,
              '13': 13,
              '14': 14,
              '15': 15,
              '16': 16,
              '17': 17, } ))

PLATFORMS = MapSpec(\
    name='platforms', 
    map=LowerDict( { 'All': 3,
                     'Linux': 1,
                     'Windows': 2 } ),
    aliases=LowerDict( { 'BOTH': 3,
              'SCIENTIFIC_LINUX': 1,
              'DEBIAN_6.0.3': 1,
              'DEBIAN': 1,
              'UBUNTU_10.10': 1,
              'UBUNTU_10.04_LTS': 1,
              'UBUNTU': 1,
              'SCIENTIFIC_LINUX_6': 1 } ))