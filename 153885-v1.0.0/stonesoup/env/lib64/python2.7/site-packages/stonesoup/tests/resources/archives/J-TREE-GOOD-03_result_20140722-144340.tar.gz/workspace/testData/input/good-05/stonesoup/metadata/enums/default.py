# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

from mapspec import MapSpec
from stonesoup.utils.dicts import LowerDict

CODE_COMPLEXITY_SOURCE_TAINT_FEATURES = MapSpec(\
    name='code_complexity_source_taint_features', 
    map=LowerDict( { 'certificate_contents': 'certificate_contents',
          'database_contents': 'database_contents',
          'environment_variable': 'environment_variable',
          'file_contents': 'file_contents',
          'file_name': 'file_name',
          'reverse_dns_lookups': 'reverse_dns_lookups',
          'socket': 'socket',
          'web_server_request': 'web_server_request',
          'shared_memory': 'shared_memory' } ),
    aliases=LowerDict( { 'certificate': 'certificate_contents',
              'cert': 'certificate_contents',
              'database': 'database_contents',
              'db': 'database_contents',
              'environment': 'environment_variable',
              'env': 'environment_variable',
              'file': 'file_contents',
              'path': 'file_name',
              'reverse_dns': 'reverse_dns_lookups',
              'dns': 'reverse_dns_lookups',
              'web_server': 'web_server_request',
              'sharedmem': 'shared_memory',
              'memory': 'shared_memory',
              'mem': 'shared_memory' } ))
              
CODE_COMPLEXITY_DATA_TYPE_FEATURES = MapSpec(\
    name='code_complexity_data_type_features', 
    map=LowerDict( { 'array': 'array',
          'simple': 'simple',
          'void_pointer': 'void_pointer',
          'heap_pointer': 'heap_pointer',
          'struct': 'struct',
          'typedef': 'typedef',
          'union': 'union' } ),
    aliases=LowerDict( ))
    
CODE_COMPLEXITY_CONTROL_FLOW_FEATURES = MapSpec(\
    name='code_complexity_control_flow_features', 
    map=LowerDict( { 'callback': 'callback',
          'indirectly_recursive': 'indirectly_recursive',
          'infinite_loop': 'infinite_loop',
          'interclass_1': 'interclass_1',
          'interclass_2': 'interclass_2',
          'interclass_10': 'interclass_10',
          'interclass_50': 'interclass_50',
          'interprocedural_1': 'interprocedural_1',
          'interprocedural_2': 'interprocedural_2',
          'interprocedural_10': 'interprocedural_10',
          'interprocedural_50': 'interprocedural_50',
          'interfile_1': 'interfile_1',
          'interfile_2': 'interfile_2',
          'interfile_10': 'interfile_10',
          'interfile_50': 'interfile_50',
          'interrupt': 'interrupt',
          'interrupt_continue': 'interrupt_continue',
          'pointer_to_function': 'pointer_to_function',
          'recursive': 'recursive',
          'sequence': 'sequence',
          'atexit': 'atexit',
          'macros': 'macros',
          'setjmp_longjmp': 'setjmp_longjmp',
          'unconditional_jump': 'unconditional_jump',
          'break_with_label': 'break_with_label',
          'function_invocation_overloading': 'function_invocation_overloading' } ),
    aliases=LowerDict( { 'int': 'interrupt',
          'int_cont': 'interrupt_continue',
          'function_pointer': 'pointer_to_function',
          'recursion': 'recursive',
          'sequence': 'sequence',
          'function_overloading': 'function_invocation_overloading',
          'function_overload': 'function_invocation_overloading',
          'indirect_recursion': 'indirectly_recursive' } ))
          
CODE_COMPLEXITY_DATA_FLOW_FEATURES = MapSpec(\
    name='code_complexity_data_flow_features', 
    map=LowerDict( { 'address_aliasing_1': 'address_aliasing_1',
          'address_aliasing_2': 'address_aliasing_2',
          'address_aliasing_10': 'address_aliasing_10',
          'address_aliasing_50': 'address_aliasing_50',
          'address_as_a_constant': 'address_as_a_constant',
          'address_as_a_function_return_value': 'address_as_a_function_return_value',
          'index_alias_1': 'index_alias_1',
          'index_alias_2': 'index_alias_2',
          'index_alias_10': 'index_alias_10',
          'index_alias_50': 'index_alias_50',
          'basic': 'basic',
          'variable_argument_list': 'variable_argument_list',
          'address_as_a_linear_expression': 'address_as_a_linear_expression',
          'address_as_a_non_linear_expression': 'address_as_a_non_linear_expression',
          'address_as_a_variable': 'address_as_a_variable',
          'buffer_address_array_index': 'buffer_address_array_index',
          'buffer_address_pointer': 'buffer_address_pointer',
          'java_generics': 'java_generics' } ),
    aliases=LowerDict( { 'varargs': 'variable_argument_list' } ))
              
CODE_COMPLEXITY_FEATURE_GROUPS = MapSpec(\
    name='code_complexity_feature_groups', 
    map=LowerDict( { 'source_taint': 'source_taint',
          'data_type': 'data_type',
          'control_flow': 'control_flow',
          'data_flow': 'data_flow' } ),
    aliases=LowerDict( { 'source': 'source_taint',
              'df': 'data_flow',
              'st': 'source_taint',
              'taint': 'source_taint',
              'dt': 'data_type',
              'cf': 'control_flow' } ))
              
GENERATION_METHODS = MapSpec(\
    name='generation_methods', 
    map=LowerDict( { 'engineered': 'engineered',
          'auto-generated': 'auto-generated',
          'fault-injected': 'fault-injected',
          'real-world': 'real-world' } ),
    aliases=LowerDict( { 'engineered': 'engineered',
          'auto_generated': 'auto-generated',
          'fault_injected': 'fault-injected',
          'real_world': 'real-world' } ))
          
LANGUAGE_TYPES = MapSpec(\
    name='language_types', 
    map=LowerDict( { 'Java': 'Java',
          'C': 'C',
          'C++': 'C++',
          'Ada': 'Ada',
          'Fortran': 'Fortran',
          'Other': 'Other' } ),
    aliases=LowerDict( ))

LANGUAGE_CLASS_TYPES = MapSpec(\
    name='language_class_types', 
    map=LowerDict( { 'Java': 'Java',
          'C': 'C',
          'x86-Linux': 'x86-Linux' } ),
    aliases=LowerDict( ))

ARCHITECTURE_TYPES = MapSpec(\
    name='architecture_types', 
    map=LowerDict( { '32-bit': '32-bit',
          '64-bit': '64-bit' } ),
    aliases=LowerDict(  ))

PROJECT_LEVEL_TYPES = MapSpec(\
    name='project_level_types', 
    map=LowerDict( { 'Elementary_Project': 'Elementary_Project',
          'Base_Project': 'Base_Project',
          'Variant_Project': 'Variant_Project' } ),
    aliases=LowerDict( { 'Elementary': 'Elementary_Project',
          'Base': 'Base_Project',
          'Variant': 'Variant_Project' } ))
          
ENTRY_POINT_TYPES = MapSpec(\
    name='entry_point_types', 
    map=LowerDict( { 'CROSSOVER_POINT': 'CROSSOVER_POINT',
          'TRIGGER_POINT': 'TRIGGER_POINT',
          'INTERACTION_POINT': 'INTERACTION_POINT' } ),
    aliases=LowerDict( { 'crossover': 'CROSSOVER_POINT',
          'trigger': 'TRIGGER_POINT',
          'interaction': 'INTERACTION_POINT' } ))
          


              