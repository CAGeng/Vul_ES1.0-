# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------


This script fixes the issue described in https://stonesoup.atlassian.net/browse/GRAMMATECH-4. It requires Python 2.7.


HOW TO

usage: fixLogFilePostProcess [-h] -v VERSION -i TESTCASES [TESTCASES ...]

optional arguments:
  -h, --help            show this help message and exit
  -v VERSION, --version VERSION ---This should always be 5.0.0
                         STEW Metadata Version
  -i TESTCASES [TESTCASES ...], --infile TESTCASES [TESTCASES ...]
                        identifier for testcases
                        
                        
                        
EXAMPLES
Run a single file:
	python fixLogFilePostProcess.py -v 5.0.0 -i C-C190-CHER-03-CF02-01/C-C190-CHER-03-CF02-01.xml 

Run a multiple files (explicit):
	python fixLogFilePostProcess.py -v 5.0.0 -i C-C190-CHER-03-CF02-01/C-C190-CHER-03-CF02-01.xml C-C190-CHER-03-CF02-02/C-C190-CHER-03-CF02-02.xml 

Run multiple files (by globbing):
	python fixLogFilePostProcess.py -v 5.0.0 -i */C-*.xml 