# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

from mapspec import MapSpec
from stonesoup.utils.dicts import LowerDict

IO_PAIR_CATEGORIES = MapSpec(\
    name='io_pair_categories', 
    map=LowerDict( { 'good': 'GOOD',
                     'bad': 'BAD' } ),
    aliases=LowerDict( ))

###############################################################################
# This is a faux enum.  It is used for input validation and mapping to 
# handlers.
###############################################################################
IO_INPUT_FEATURES = MapSpec(\
    name='io_input_sources', 
    map=LowerDict( { 'database_content_input': 'database_content_input',
                     'command_line_input': 'command_line_input',
                     'env_var_input': 'env_var_input',
                     'file_content_input': 'file_content_input',
                     'reverse_dns_lookup_input': 'reverse_dns_lookup_input',
                     'socket_input': 'socket_input',
                     'shared_memory_input': 'shared_memory_input',
                     'script_input': 'script_input',
                     'stdin_input': 'stdin_input' } ),
    aliases=LowerDict( { 'database': 'database_content_input',
                         'command_line': 'command_line_input',
                         'cli': 'command_line_input',
                         'args': 'command_line_input',
                         'commandline': 'command_line_input',
                         'environment_variable': 'env_var_input',
                         'environment': 'env_var_input',
                         'env': 'env_var_input',
                         'envvar': 'env_var_input',
                         'export': 'env_var_input',
                         'file_contents': 'file_content_input',
                         'filecontents': 'file_content_input',
                         'file': 'file_content_input',
                         'shared_memory': 'shared_memory_input',
                         'sharedmemory': 'shared_memory_input',
                         'sharedmem': 'shared_memory_input',
                         'mem': 'shared_memory_input',
                         'dns': 'reverse_dns_lookup_input',
                         'dns_lookup': 'reverse_dns_lookup_input',
                         'dnslookup': 'reverse_dns_lookup_input',
                         'script': 'script_input',
                         'command': 'script_input',
                         'process': 'script_input',
                         'subprocess': 'script_input',
                         'stdin': 'stdin_input',
                         'socket': 'socket_input' } ))

IO_VALUE_TYPES = MapSpec(\
    name='io_value_types', 
    map=LowerDict( { 'use_text_directly': 'USE_TEXT_DIRECTLY',
          'use_contents_of_file': 'USE_CONTENTS_OF_FILE' } ),
    aliases=LowerDict( { 'TEXT_DIRECTLY': 'USE_TEXT_DIRECTLY',
              'text': 'USE_TEXT_DIRECTLY',
              'contents_of_file': 'USE_CONTENTS_OF_FILE',
              'file': 'USE_CONTENTS_OF_FILE' } ))
              
TECHNICAL_IMPACTS = MapSpec(\
    name='technical_impacts', 
    map=LowerDict( { 'NONE': 'NONE',
          'UNSPECIFIED': 'UNSPECIFIED',
          'READ_FILES': 'READ_FILES',
          'READ_APPLICATION_DATA': 'READ_APPLICATION_DATA',
          'GAIN_PRIVILEGES': 'GAIN_PRIVILEGES',
          'HIDE_ACTIVITIES': 'HIDE_ACTIVITIES',
          'EXECUTE_UNAUTHORIZED_CODE': 'EXECUTE_UNAUTHORIZED_CODE',
          'MODIFY_FILES': 'MODIFY_FILES',
          'MODIFY_APPLICATION_DATA': 'MODIFY_APPLICATION_DATA',
          'BYPASS_PROTECTION_MECHANISM': 'BYPASS_PROTECTION_MECHANISM',
          'ALTER_EXECUTION_LOGIC': 'ALTER_EXECUTION_LOGIC',
          'UNEXPECTED_STATE': 'UNEXPECTED_STATE',
          'DOS_UNCONTROLLED_EXIT': 'DOS_UNCONTROLLED_EXIT',
          'DOS_AMPLIFICATION': 'DOS_AMPLIFICATION',
          'DOS_INSTABILITY': 'DOS_INSTABILITY',
          'DOS_BLOCKING': 'DOS_BLOCKING',
          'DOS_RESOURCE_CONSUMPTION': 'DOS_RESOURCE_CONSUMPTION' } ),
    aliases=LowerDict( ))

PLATFORMS = MapSpec(\
    name='platforms', 
    map=LowerDict( { 'All': 'All',
                     'Linux': 'Linux',
                     'Windows': 'Windows',
                     'Scientific_Linux_6': 'Scientific_Linux_6',
                     'Debian_6.0.3': 'Debian_6.0.3',
                     'Ubuntu_10.10': 'Ubuntu_10.10',
                     'Ubuntu_10.04_LTS': 'Ubuntu_10.04_LTS' } ),
    aliases=LowerDict( ))
              
DATABASE_TYPES = MapSpec(\
    name='database_types', 
    map=LowerDict( { 'mysql': 'MySQL',
                     'sqlserver': 'SQLServer',
                     'postgresql': 'PostgreSQL' } ),
    aliases=LowerDict( { 'mssql': 'SQLServer',
              'mssqlserver': 'SQLServer',
              'postgres': 'PostgreSQL',
              'postgre': 'PostgreSQL' } ))

IO_OUTPUT_VALUE_CHECK_TYPES = MapSpec(\
    name='output_value_check_types', 
    map=LowerDict( { 'run_check_script': 'run_check_script',
                     'regular_expression': 'regular_expression',
                     'exact_match': 'exact_match',
                     'contains': 'contains',
                     'check_stage1': 'check_stage1' } ),
    aliases=LowerDict( { 'script': 'run_check_script',
              'regex': 'regular_expression',
              'exact': 'exact_match',
              'equals': 'exact_match',
              'stage1': 'check_stage1' } ))

IO_OUTPUT_TYPES = MapSpec(\
    name='output_types', 
    map=LowerDict( { 'file_contents': 'file_contents',
                     'file_name': 'file_name',
                     'return_status': 'return_status',
                     'stdout_terminal': 'stdout_terminal',
                     'stderr_terminal': 'stderr_terminal',
                     'does_not_return': 'does_not_return' } ),
    aliases=LowerDict( { 'filename': 'file_name',
              'file_contents': 'filecontents',
              'return_code': 'return_status',
              'stdout': 'stdout_terminal',
              'stderr': 'stderr_terminal' } ))

IO_OUTPUT_OPERATORS = MapSpec(\
    name='output_operators', 
    map=LowerDict( { 'AND': 'AND',
                     'OR': 'OR',
                     'NOT': 'NOT' } ),
    aliases=LowerDict( ))