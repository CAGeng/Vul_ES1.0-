package stonesoup.jtree.tar;

/*
 # ------------------------------Copyright-------------------------------------
 # NOTICE
 # 
 # This software (or technical data) was produced for the U. S.
 # Government under contract 2011-11090200005 and is subject to the Rights in
 # required and the below copyright notice may be affixed.
 # 
 # Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
 # -----------------------------Copyright-------------------------------------- 
 */

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;

import stonesoup.jtree.TreePrinter;

public class TarTreePrinter extends TreePrinter {

	public TarTreePrinter() {
		this(-1);
	}

	public TarTreePrinter(int maxLevel) {
		super(maxLevel);
	}

	public void run(String tar) {
		run(new File(tar));
	}

	public void run(File tar) {
		String tmpDir = getExplodedDirectory(tar);
		super.run(new File(tmpDir));
		cleanup(tmpDir);
	}

	private String getExplodedDirectory(File tar) {

		File temp = null;
		InputStream headerStream = null;
		TarArchiveInputStream sourceTar = null;
		try {
			temp = File.createTempFile("tempTreeFile",
					Long.toString(System.nanoTime()));
			temp.delete();
			if (!(temp.mkdirs())) {

				throw new IOException("Could not create temp directory: "
						+ temp.getAbsolutePath());
			}

			// Get the header to figure out if the stream is compressed
			headerStream = new FileInputStream(tar);
			byte[] header = new byte[64];
			headerStream.read(header);
			headerStream.close();

			if (isGzipStream(header)) {
				sourceTar = new TarArchiveInputStream(new GZIPInputStream(
						new FileInputStream(tar)));
			} else {
				sourceTar = new TarArchiveInputStream(new FileInputStream(tar));
			}

			ArchiveEntry entry;
			while ((entry = sourceTar.getNextEntry()) != null) {
				int count;
				byte data[] = new byte[2048];

				File tmpFile = new File(temp.getAbsolutePath() + "/"
						+ entry.getName());
				tmpFile.mkdirs();
				if (!tmpFile.isDirectory()) {
					FileOutputStream fos = new FileOutputStream(
							temp.getAbsolutePath() + "/" + entry.getName());
					BufferedOutputStream dest = new BufferedOutputStream(fos);

					while ((count = sourceTar.read(data)) != -1) {
						dest.write(data, 0, count);
					}

					dest.flush();
					dest.close();
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				sourceTar.close();
			} catch (IOException e) {
				// Swallow the exception to close quietly
			}
		}

		return temp.getAbsolutePath();
	}

	private static boolean isGzipStream(byte[] bytes) {
		int head = ((int) bytes[0] & 0xff) | ((bytes[1] << 8) & 0xff00);
		return (GZIPInputStream.GZIP_MAGIC == head);
	}

	private void cleanup(String tmpDir) {
		File temp = new File(tmpDir);
		File[] files = temp.listFiles();
		for (File file : files) {
			if (file.isDirectory())
				cleanup(file.getAbsolutePath());
			else
				file.delete();
		}
		temp.delete();
	}

}
