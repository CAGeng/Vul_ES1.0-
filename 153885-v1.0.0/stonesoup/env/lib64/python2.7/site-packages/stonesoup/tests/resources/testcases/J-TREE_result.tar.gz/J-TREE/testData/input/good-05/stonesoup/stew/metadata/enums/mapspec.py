# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

from stonesoup.utils.dicts import LowerDict

class MapSpec(object) :
    def __init__(self, name='', map=LowerDict(), aliases=LowerDict()) :
        '''
        Defines a named map for marshalling and unmarshalling internal types to a specific
        metadata specification version.
        '''
        self.name = name
        self.map = map
        self.aliases = aliases
        self.union = LowerDict(aliases)
        self.union.update(map)
        return
