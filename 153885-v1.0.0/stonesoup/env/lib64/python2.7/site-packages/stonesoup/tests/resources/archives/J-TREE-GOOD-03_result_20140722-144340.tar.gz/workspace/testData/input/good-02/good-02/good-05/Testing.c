#include <stdlib.h>


int main(){
	
	char * value=0;
	int size=0;
	char * buffer=0;
	int i=0;
	value=getenv("ENVVARIABLE");
	size=atoi(value);
	buffer=malloc(size);
	for(i; i<size; i++){
		buffer[i]='A';
	}
	buffer[size]='\0';
}

