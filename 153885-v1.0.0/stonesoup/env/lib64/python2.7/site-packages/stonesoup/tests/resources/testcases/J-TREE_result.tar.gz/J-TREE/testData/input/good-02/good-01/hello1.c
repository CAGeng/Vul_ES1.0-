// ------------------------------Copyright-------------------------------------
// NOTICE
//
// This software (or technical data) was produced for the U. S.
// Government under contract 2011-11090200005 and is subject to the Rights in
// Data-General Clause 52.227-14 (DEC 2007).
//
// Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
// -----------------------------Copyright--------------------------------------
//#include <stdio.h>
//#include <stdlib.h>

int main(int argc,char *argv[])
{
    int x = 5;
    double y = 20.5;
    
#pragma vulnseed
    y = y * x + 1.11111;
    //printf("Hello, %2.2f\n",y);
    return (int )y;
}

void woah()
{
    int a = 1;
    a++;
}