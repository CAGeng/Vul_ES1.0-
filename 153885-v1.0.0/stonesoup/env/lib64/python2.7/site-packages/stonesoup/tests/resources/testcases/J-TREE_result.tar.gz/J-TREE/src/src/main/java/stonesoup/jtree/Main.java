package stonesoup.jtree;

/*
 # ------------------------------Copyright-------------------------------------
 # NOTICE
 # 
 # This software (or technical data) was produced for the U. S.
 # Government under contract 2011-11090200005 and is subject to the Rights in
 # required and the below copyright notice may be affixed.
 # 
 # Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
 # -----------------------------Copyright-------------------------------------- 
 */

import java.io.PrintWriter;

import org.apache.commons.cli.ParseException;

import stonesoup.jtree.directory.DirectoryTreePrinter;
import stonesoup.jtree.tar.TarTreePrinter;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JTreeOptions options = new JTreeOptions();

		if (args.length == 0) {
			options.printHelp(new PrintWriter(System.out, true));
			System.exit(0);
		}

		/* Parse the options, and print the help/usage on failure. */
		try {
			options.parseOptions(args);
		} catch (ParseException e) {
			System.err.println("Invalid arguments.");
			options.printHelp(new PrintWriter(System.err, true));
			System.exit(1);
		}

		if (options.getHelp()) {
			options.printHelp(new PrintWriter(System.out, true));
			System.exit(0);
		}

		/* validate args */
		if (options.getInputFiles().size() < 1) {
			System.err.println("At least one input file is required.");
			System.exit(1);
		}

		for (String file : options.getInputFiles()) {
			ITreePrinter printer;
			if (options.hasMaxLevel()) {
				if (file.contains(".tar.gz")) {
					printer = new TarTreePrinter(options.getMaxLevel());
				} else {
					printer = new DirectoryTreePrinter(options.getMaxLevel());
				}
			} else {
				if (file.contains(".tar.gz")) {
					printer = new TarTreePrinter();
				} else {
					printer = new DirectoryTreePrinter();
				}
			}

			printer.run(file);
		}

	}

}
