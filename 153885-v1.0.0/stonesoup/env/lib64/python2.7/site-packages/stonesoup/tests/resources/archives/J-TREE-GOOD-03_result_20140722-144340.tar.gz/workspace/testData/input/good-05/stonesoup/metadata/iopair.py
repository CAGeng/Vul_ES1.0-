# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright--------------------------------------

import itertools
import copy

from stonesoup.utils.dicts import LowerDict

class BaseIOPair(LowerDict) :
    def __init__(self, *args, **kwargs):
        self.__version = kwargs.pop('version')
        self.__enums = kwargs.pop('metadata_enums')
        self._spec = kwargs.pop('metadata_spec')
        
        super(BaseIOPair, self).__init__(*args, **kwargs)
        
        #load the enumerations
        self._enum_io_input_sources = self.enums['io_input_sources']
        self._enum_io_pair_categories = self.enums['io_pair_categories']
        self._enum_io_value_types = self.enums['io_value_types']
        self._enum_technical_impacts = self.enums['technical_impacts']
        self._enum_platforms = self.enums['platforms']
        
        #apply version specific defaults
        extra_defaults = self._extra_defaults()
        if extra_defaults is not None :
            for key, value in extra_defaults.iteritems() :
                if key not in self :
                    self[key] = value
                    
        #apply defaults
        defaults = self.__defaults()
        for key, value in defaults.iteritems() :
            if key not in self :
                self[key] = value
        
        return
    
    def __defaults(self) :
        return { 'name': None, 
                 'category': None, 
                 'technical_impact': None, 
                 'platform': None, 
                 'timeout_execute': None,
                 'inputs': { 'co_process': [ ],
                             'pre_process': [ ],
                             'post_process': [ ] },
                 'outputs': [ ] }
    
    def _extra_defaults(self) :
        return None
        
    @property
    def version(self) :
        return self.__version
        
    @property
    def enums(self) :
        return self.__enums
        
    @property
    def name(self) :
        return self['name']
    
    @name.setter
    def name(self, value) :
        self['name'] = value
    
    @property
    def category(self) :
        return self['category']
    
    @category.setter
    def category(self, value) :
        if value is None :
            self['category'] = None
            return
        
        if not self._enum_io_pair_categories.is_valid(value) :
            raise ValueError('category is not supported.')
        
        self['category'] = self._enum_io_pair_categories.marshall(value)
    
    @property
    def is_good(self) :
        return self['category'] == self._enum_io_pair_categories.marshall('good')
    
    @property
    def is_bad(self) :
        return not self.is_good
        
    @property
    def technical_impact(self) :
        return self['technical_impact']
    
    @technical_impact.setter
    def technical_impact(self, value) :
        if value is None :
            self['technical_impact'] = None
            return
        
        if not self._enum_technical_impacts.is_valid(value) :
            raise ValueError('technical impact is not supported.')
        
        self['technical_impact'] = self._enum_technical_impacts.marshall(value)
    
    @property
    def platform(self) :
        return self['platform']
    
    @platform.setter
    def platform(self, value) :
        if value is None :
            self['platform'] = None
            return
        
        if not self._enum_platforms.is_valid(value) :
            raise ValueError('platform is not supported.')
        
        self['platform'] = self._enum_platforms.marshall(value)
    
    @property
    def timeout_execute(self) :
        return self['timeout_execute']
    
    @timeout_execute.setter
    def timeout_execute(self, value) :
        enc_value = value
        if isinstance(value, str) :
            enc_value = int(value)
        self['timeout_execute'] = enc_value
    
    @property
    def inputs(self) :
        return self['inputs']
        
    @property
    def inputs_co_processes(self) :
        return self['inputs']['co_process']
    
    @property
    def inputs_pre_processes(self) :
        return self['inputs']['pre_process']
    
    @property
    def inputs_post_processes(self) :
        return self['inputs']['post_process']
    
    @property
    def outputs(self) :
        return self['outputs']
        
    def _build_new(self, **kwargs) :
        return None
    
    def clone(self) :
        result = self._build_new(version=self.__version,
            metadata_enums=self.__enums,
            metadata_spec=self._spec)
            
        if result is None :
            raise RuntimeError('Type does not support cloning.')
        
        for key, value in self.iteritems() :
            result[key] = copy.deepcopy(value)
        
        return result


class StewIOPair2_0_1(BaseIOPair) :
    def __init__(self, *args, **kwargs):
        super(StewIOPair2_0_1, self).__init__(*args, **kwargs)
        return
        
    def add_input_parameter(self,
                            **kwargs) :
        
        stage = kwargs.get('stage', 'pre_process').lower()
        source = kwargs.get('source', None)
        value = kwargs.get('value', None)
        value_type = kwargs.get('value_type', 'text').lower()
        
        if stage == 'co_process' :
            source = None
            value_type = None
        else :
            stage = 'pre_process'
            if source is None :
                raise ValueError('input source not specified.')
            if value is None :
                raise ValueError('input value not specified.')
        
        parameter = { 'type': 'input',
                      'stage': stage,
                      'source': source,
                      'value': value,
                      'value_type': value_type }
        
        self['inputs'][stage].append(parameter)
        
        return parameter
    
    def add_output_parameter(self,
                             **kwargs) :
                             
        source = kwargs.get('source', None)
        value = kwargs.get('value', None)
        value_type = kwargs.get('value_type', 'text').lower()
        
        if source is None :
            raise ValueError('input source not specified.')
        if value is None :
            raise ValueError('input value not specified.')
        
        parameter = { 'type': 'output',
                      'source': source,
                      'value': value,
                      'value_type': value_type }
        
        self['outputs'].append(parameter)
        
        return parameter
    
    def _build_new(self, **kwargs) :
        return StewIOPair2_0_1(**kwargs)

class StewIOPair2_1_0(BaseIOPair) :
    def __init__(self, *args, **kwargs):
        super(StewIOPair2_1_0, self).__init__(*args, **kwargs)
        
        #load the enumerations
        self._enum_database_types = self.enums['database_types']
        self._enum_output_value_check_types = self.enums['output_value_check_types']
        self._enum_output_types = self.enums['output_types']
        self._enum_output_operators = self.enums['output_operators']
        
        self._stages = set (['pre_process', 'co_process', 'post_process'])
        return
        
    def _extra_defaults(self) :
        return { 'description': None,
                 'do_reset': True,
                 'command_line_input': None,
                 'stdin_input': None,
                 'outputs': None }
    
    def _build_new(self, **kwargs) :
        return StewIOPair2_1_0(**kwargs)
    
    @property
    def description(self) :
        return self['description']
    
    @description.setter
    def description(self, value) :
        self['description'] = value
        
    @property
    def do_reset(self) :
        return self['do_reset']
    
    @do_reset.setter
    def do_reset(self, value) :
        if value is None :
            value = True
        else :
            if isinstance(value, str) :
                value = value.lower().strip() == 'true'
        
        self['do_reset'] = value
    
    @property
    def command_line_input(self) :
        return self['command_line_input']
    
    @command_line_input.setter
    def command_line_input(self, value) :
        self['command_line_input'] = value
    
    @property
    def stdin_input(self) :
        return self['stdin_input']
    
    @stdin_input.setter
    def stdin_input(self, value) :
        self['stdin_input'] = value
        
    def add_input_parameter(self,
                            **kwargs) :
        
        index = kwargs.get('index', None)
        stage = kwargs.get('stage', 'pre_process').lower()
        source = kwargs.get('source', None)
        input_id = kwargs.get('id', None)
        
        # we always must have a source type (e.g. command line, database, etc.)
        if source is None :
            raise ValueError('input source not specified.')
            
        if not self._enum_io_input_sources.is_valid(source) :
            raise ValueError('input source not supported.')
        
        source_enum = self._enum_io_input_sources.marshall(source).lower()
        
        source_specific_args = None
        
        if source_enum == 'command_line_input' :
            value = kwargs.get('value', None)
            if value is None :
                raise ValueError('command line arguments not specified.')
            self['command_line_input'] = value
            return { 'command_line_input': value }
        elif source_enum == 'stdin_input' :
            value = kwargs.get('value', None)
            if value is None :
                raise ValueError('stdin value not specified.')
            self['stdin_input'] = value
            return { 'stdin_input': value }
        else :
            source_specific_extractor = getattr(self, '_extract_input_parameter_' + source_enum, 
                self._extract_input_parameter_generic)
            source_specific_args = source_specific_extractor(**kwargs)
        
        if stage not in self._stages :
            raise ValueError('input stage not supported.')
        
        # GCM - What was this for?
        #if stage == 'co_process' :
        #    source = None
        #    value_type = None
        #else :
        #    stage == 'pre_process'
        #    if source is None :
        #        raise ValueError('input source not specified.')
        
        # build common params
        parameter = { 'type': 'input',
                      'source': source_enum,
                      'id': input_id }
        
        # build source specific
        parameter.update(source_specific_args)
        
        if index is None :
            self['inputs'][stage].append(parameter)
        else :
            if isinstance(index, str) :
                # decode string to int value
                index = int(index)
            elif isinstance(index, dict) :
                # lookup by value
                try :
                    index = self['inputs'][stage].index(index)
                except IndexError :
                    index = len(self['inputs'][stage])
            if index > len(self['inputs'][stage]) :
                index = len(self['inputs'][stage])
            elif index < 0 :
                index = 0
            self['inputs'][stage].insert(index, parameter)
        
        return parameter
        
    def _add_input_parameter_command_line(self,
                                         **kwargs) :
        return self._add
        
    def _extract_input_parameter_value_with_type(self,
                                                  value_field_name='value',
                                                  **kwargs) :
        value = kwargs.get(value_field_name, None)
        value_type = kwargs.get('%s_type' % value_field_name, 'text').lower()
        
        if value is None :
            raise ValueError('input %s not specified.' % value_field_name)
            
        
        
        if value_type is None :
            raise ValueError('input %s type not specified.' % value_field_name)
        if not self._enum_io_value_types.is_valid(value_type) :
            raise ValueError('input %s type not supported.' % value_field_name)
            
        return { value_field_name: value,
                 '%s_type' % value_field_name: self._enum_io_value_types.marshall(value_type) }
    
    def _extract_input_parameter_generic(self,
                                          **kwargs) :
        return { }
        
    def _extract_input_parameter_database_content_input(self,
                                                         **kwargs) :
        server = kwargs.get('server', None)
        database = kwargs.get('database', None)
        port = kwargs.get('port', None)
        
        if database is None :
            raise ValueError('database type not specified.')
        if not self._enum_database_types.is_valid(database) :
            raise ValueError('database type not supported.')
        
        if server is None :
            raise ValueError('database server address not specified.')
        
        database_enum = self._enum_database_types.marshall(database).lower()
        
        if port is None :
            if database_enum == 'mysql' :
                port = 3306
            elif database_enum == 'sqlserver' :
                port = 1433
            elif database_enum == 'postgresql' :
                port = 5432
            else :
                raise ValueError('database port not specified.')
        elif isinstance(port, str) :
            port = int(port)
        
        parameters = { 'server': server,
                       'database': self._enum_database_types.marshall(database),
                       'port': port }
        parameters.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        return parameters
        
    def _extract_input_parameter_env_var_input(self,
                                                **kwargs) :
        name = kwargs.get('name', None)
        
        if name is None :
            raise ValueError('environment variable name not specified.')
        
        parameters = { 'name': name }
        parameters.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        return parameters
        
    def _extract_input_parameter_file_content_input(self,
                                                     **kwargs) :
        name = kwargs.get('name', None)
        
        if name is None :
            raise ValueError('file name not specified.')
        
        parameters = { 'name': name }
        parameters.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        return parameters
        
    def _extract_input_parameter_reverse_dns_lookup_input(self,
                                                           **kwargs) :
        dns = kwargs.get('dns', None)
        ip = kwargs.get('ip', None)
        
        if dns is None :
            raise ValueError('domain name not specified.')
        if ip is None :
            raise ValueError('ip address not specified.')
        
        parameters = { 'dns': dns,
                       'ip': ip }
        
        return parameters
    
    def _extract_input_parameter_socket_input(self,
                                               **kwargs) :
        address = kwargs.get('address', None)
        port = kwargs.get('port', None)
        
        if address is None :
            raise ValueError('host address not specified.')
        if port is None :
            raise ValueError('host port not specified.')
        
        if isinstance(port, str) :
            port = int(port)
        
        parameters = { 'address': address,
                       'port': port }
        parameters.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        return parameters
    
    def _extract_input_parameter_shared_memory_input(self,
                                                     **kwargs) :
        flags_ipc_creat = 512
        flags_ipc_excl = 1024
        flags_ipc_nowait = 2048
        flags_default = flags_ipc_creat + flags_ipc_excl
        flags_allowed = set([flags_ipc_creat, 
                            flags_ipc_excl, 
                            flags_ipc_nowait,
                            flags_ipc_creat + flags_ipc_excl,
                            flags_ipc_creat + flags_ipc_nowait,
                            flags_ipc_excl + flags_ipc_nowait,
                            flags_ipc_creat + flags_ipc_excl + flags_ipc_nowait])

        key = kwargs.get('key', None)
        flags = kwargs.get('flags', None)
        size = kwargs.get('size', None)
        
        if key is None :
            raise ValueError('shared memory key not specified.')
        if size is None :
            raise ValueError('shared memory size not specified.')
        if flags is None :
            flags = flags_default
        elif isinstance(flags, str) :
            flags = int(flags)
            if flags not in flags_allowed :
                raise ValueError('shared memory flags not supported.')
        
        if isinstance(size, str) :
            size = int(size)
        
        parameters = { 'key': key,
                       'size': size,
                       'flags': flags }
        parameters.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        return parameters
        
    def _extract_input_parameter_script_input(self,
                                               **kwargs) :
        name = kwargs.get('name', None)
        
        if name is None :
            raise ValueError('script name not specified.')
        
        parameters = { 'name': name }
        
        return parameters
    
    def add_output_parameter_group(self,
                                   parent=None,
                                   **kwargs) :
        operator = kwargs.get('operator', 'and')
        child_outputs = kwargs.get('outputs', None)
        child_groups = kwargs.get('groups', None)
        
        if operator is None :
            operator = 'and'
        
        if not self._enum_output_operators.is_valid(operator) : 
            raise ValueError('output operator not supported.')
        
        parameter = { 'type': 'output_group',
                      'operator': self._enum_output_operators.marshall(operator),
                      'outputs': [],
                      'groups': [] }
        
        if child_outputs is not None :
            for item in child_outputs :
                self.add_output_parameter(parent=parameter, **item)
        if child_groups is not None :
            for item in child_groups :
                self.add_output_parameter_group(parent=parameter, **item)
        
        if parent is None :
            self['outputs'] = parameter
        else :
            if 'type' not in parent :
                raise ValueError('Invalid parent provided.')
            if parent['type'] != 'output_group' :
                raise ValueError('Invalid parent type provided.  Expected an \'output_group\'.')
            parent['groups'].append(parameter)
        
        return parameter
    
    def add_output_parameter(self,
                             parent=None,
                             **kwargs) :
        
        source = kwargs.get('source', None)
        input = kwargs.get('input', None)
        check = kwargs.get('check', 'equals')
        target_file = kwargs.get('target_file', None)
        
        if source is None :
            raise ValueError('output source not specified.')
        
        if not self._enum_output_types.is_valid(source) : 
            raise ValueError('output source not supported.')
        if not self._enum_output_value_check_types.is_valid(check) : 
            raise ValueError('output check type not supported.')
        
        parameter = { 'type': 'output',
                      'source': self._enum_output_types.marshall(source),
                      'input': input,
                      'check': self._enum_output_value_check_types.marshall(check) }
        parameter.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        if parent is None :
            # add a default group container
            parent = self.add_output_parameter_group(operator=kwargs.get('operator', None))
        else :
            if 'type' not in parent :
                raise ValueError('Invalid parent provided.')
            if parent['type'] != 'output_group' :
                raise ValueError('Invalid parent type provided.  Expected an \'output_group\'.')
        
        parent['outputs'].append(parameter)
        
        return parent
    
    def marshall(self) :
        # build the command with optional stdin value
        command = self['command_line_input']
        if self['stdin_input'] is not None :
            command = '%s <%s' % (command, self['stdin_input'])
        
        # create the io pair global values
        io_pair = self._spec.ioPairType(name=self['name'], 
                                         description=self['description'], 
                                         timeout_execute=self['timeout_execute'], 
                                         do_reset=self['do_reset'], 
                                         io_pair_category=self['category'], 
                                         platform=self['platform'], 
                                         technical_impact=self['technical_impact'], 
                                         command_line_input=\
                                            self._spec.valueWithType(val=command,
                                                value_type=self._enum_io_value_types.marshall('text')))
                               
        # add the inputs
        for stage in self._stages :
            stage_inputs = self['inputs'][stage]
            if stage_inputs is None or\
                    len(stage_inputs) == 0:
                continue
            input_group = self._spec.ioInputGroupType()
            for ordinal, input in itertools.izip(itertools.count(1),\
                    stage_inputs) :
                getattr(input_group, 'add_%s' % input['source'])(\
                    getattr(self,\
                        '_build_input_parameter_%s' % input['source'])(input, ordinal))
            getattr(io_pair, 'set_%s' % stage)(\
                self._spec.inputGroupsType(input_groups=input_group))
        
        # add the outputs
        if self['outputs'] is not None :
            io_pair.set_output_group(self._build_output_group(self['outputs']))
        
        return io_pair
    
    def unmarshall(self, enc_io_pair) :
        self['name'] = enc_io_pair.get_name()
        self['description'] = enc_io_pair.get_description()
        self['timeout_execute'] = enc_io_pair.get_timeout_execute()
        self['do_reset'] = enc_io_pair.get_do_reset()
        self['category'] = enc_io_pair.get_io_pair_category()
        self['platform'] = enc_io_pair.get_platform()
        self['technical_impact'] = enc_io_pair.get_technical_impact()
        self['command_line_input'] = None
        if enc_io_pair.get_command_line_input() is not None :
            self['command_line_input'] = enc_io_pair.get_command_line_input().get_val()
        
        if self['command_line_input'] is not None :
            command, redirect, stdin = self['command_line_input'].rpartition(' <')
            if redirect is None or redirect == '' :
                pass
            else :
                self['command_line_input'] = command.strip()
                self['stdin_input'] = stdin.strip()
        
        # decode the inputs
        for stage in self._stages :
            self['inputs'][stage] = [ ]
            enc_io_inputs = getattr(enc_io_pair, 'get_%s' % stage)()
            if enc_io_inputs is None :
                continue
            #load the inputs
            self._load_input_stage(stage, enc_io_inputs)
            
        # decode the outputs
        enc_io_outputs = enc_io_pair.get_output_group()
        if enc_io_outputs is not None :
            self['outputs'] = self._load_output_group(enc_io_outputs)
        
        return
        
        
    def _load_input_stage(self,
                           stage,
                           element) :
        enc_io_inputs = element.get_input_groups()
        if enc_io_inputs is None :
            return
        enc_io_inputs_all = [ ]
        enc_io_inputs_all.extend(enc_io_inputs.get_database_content_input())
        enc_io_inputs_all.extend(enc_io_inputs.get_env_var_input())
        enc_io_inputs_all.extend(enc_io_inputs.get_file_content_input())
        enc_io_inputs_all.extend(enc_io_inputs.get_reverse_dns_lookup_input())
        enc_io_inputs_all.extend(enc_io_inputs.get_socket_input())
        enc_io_inputs_all.extend(enc_io_inputs.get_shared_memory_input())
        enc_io_inputs_all.extend(enc_io_inputs.get_script_input())
        #make sure order is int type
        for enc_io_input in enc_io_inputs_all :
            if enc_io_input.get_order() is not None :
                enc_io_input.set_order(int(enc_io_input.get_order()))
        #sort by order
        enc_io_inputs_all.sort(key = lambda x: x.order)
        for enc_io_input in enc_io_inputs_all :
            raw_io_input = getattr(self, 
                '_load_input_parameter_%s' %\
                    enc_io_input.__class__.__name__)(enc_io_input)
            self['inputs'][stage].append(raw_io_input)
        return
    
    def _load_output_item(self,
                          element) :
        
        parameter = { 'type': 'output',
                      'source': element.get_output_type(),
                      'input': element.get_inputIDREF(),
                      'check': element.get_value_check_type() }
        parameter.update(self._load_value_with_type(element.get_value()))
        
        return parameter
        
        
    def _load_output_group(self,
                           element) :
        enc_io_outputs = element.get_io_outputs()
        
        if enc_io_outputs is not None :
            enc_io_outputs = enc_io_outputs.get_io_output()
            if enc_io_outputs is None or\
                    len(enc_io_outputs) == 0 :
                enc_io_outputs = None
        
        # make the group
        parameter = { 'type': 'output_group',
                      'operator': element.get_operator(),
                      'outputs': [],
                      'groups': [] }
        
        # load the output values
        if enc_io_outputs is not None :
            for enc_io_output in enc_io_outputs :
                parameter['outputs'].append(self._load_output_item(enc_io_output))
        
        # load child groups
        
        # get children
        enc_children = element.get_output_groups()
        if enc_children is not None :
            enc_children = enc_children.get_output_group()
            if enc_children is not None and\
                    len(enc_children) > 0 :
                for enc_child in enc_children :
                    parameter['groups'].append(self._load_output_group(enc_child))
        
        return parameter
                      
        
    def _load_value_with_type(self,
                            element) :
        if element is None :
            return { 'value': None,
                     'value_type': None }
        return { 'value': element.get_val(),
                 'value_type': element.get_value_type() }
    
    def _load_input_parameter_common_values(self,
                                            element) :
        return { 'id': element.get_inputID(),
                 'type': 'input' }
    
    def _load_input_parameter_databaseContentsType(self,
                                                    element) :
        result = { 'server': element.get_server(),
                   'database': element.get_database(),
                   'port': element.get_port_number(),
                   'source': 'database_content_input' }
        result.update(self._load_value_with_type(element.get_sql()))
        result.update(self._load_input_parameter_common_values(element))
        
        return result
    
    def _load_input_parameter_environmentVariableType(self,
                                                      element) :
        result = { 'name': element.get_name(),
                   'source': 'env_var_input' }
        result.update(self._load_value_with_type(element.get_value()))
        result.update(self._load_input_parameter_common_values(element))
        
        return result
    
    def _load_input_parameter_fileContentsType(self,
                                                element) :
        result = { 'name': element.get_name(),
                   'source': 'file_content_input' }
        result.update(self._load_value_with_type(element.get_content()))
        result.update(self._load_input_parameter_common_values(element))
        
        return result
    
    def _load_input_parameter_reverseDnsLookupsType(self,
                                                     element) :
        result = { 'dns': element.get_domain_name(),
                   'ip': element.get_ip_address(),
                   'source': 'reverse_dns_lookup_input' }
        result.update(self._load_input_parameter_common_values(element))
        
        return result
        
    def _load_input_parameter_socketType(self,
                                          element) :
        result = { 'address': element.get_address(),
                   'port': element.get_port_number(),
                   'source': 'socket_input' }
        result.update(self._load_value_with_type(element.get_data()))
        result.update(self._load_input_parameter_common_values(element))
        
        return result
    
    def _load_input_parameter_sharedMemoryType(self,
                                                element) :
        result = { 'key': element.get_key(),
                   'flags': element.get_shmflg(),
                   'size': element.get_size(),
                   'source': 'shared_memory_input' }
        result.update(self._load_value_with_type(element.get_value()))
        result.update(self._load_input_parameter_common_values(element))
        
        return result
        
    def _load_input_parameter_scriptType(self,
                                          element) :
        result = { 'name': element.get_name(),
                    'source': 'script_input' }
        result.update(self._load_input_parameter_common_values(element))
        
        return result
        
    def _build_value_with_type(self,
                                params) :
        return self._spec.valueWithType(val=params['value'],
                                        value_type=params['value_type'])
        
    def _build_input_parameter_database_content_input(self,
                                                       params,
                                                       ordinal) :
        database = self._spec.databaseContentsType(server=params['server'], 
                                                    database=self._enum_database_types.\
                                                        marshall(params['database']), 
                                                    port_number=params['port'], 
                                                    order=ordinal, 
                                                    inputID=params['id'],
                                                    sql=self._build_value_with_type(params))
        return database
    
    def _build_input_parameter_env_var_input(self,
                                              params,
                                              ordinal) :
        env_variable = self._spec.environmentVariableType(name=params['name'], 
                                                           order=ordinal, 
                                                           inputID=params['id'], 
                                                           value=self._build_value_with_type(params))
        return env_variable
        
    def _build_input_parameter_file_content_input(self,
                                                   params,
                                                   ordinal) :
        file_contents = self._spec.fileContentsType(name=params['name'], 
                                                    order=ordinal, 
                                                    inputID=params['id'], 
                                                    content=self._build_value_with_type(params))
        return file_contents
        
    def _build_input_parameter_reverse_dns_lookup_input(self,
                                                         params,
                                                         ordinal) :
        reverse_dns = self._spec.reverseDnsLookupsType(domain_name=params['dns'], 
                                                        ip_address=params['ip'], 
                                                        order=ordinal, 
                                                        inputID=params['id'])
        return reverse_dns
    
    def _build_input_parameter_socket_input(self,
                                             params,
                                             ordinal) :
        socket_val = self._spec.socketType(address=params['address'], 
                                            port_number=params['port'], 
                                            order=ordinal, 
                                            inputID=params['id'],
                                            data=self._build_value_with_type(params))
        return socket_val
    
    def _build_input_parameter_shared_memory_input(self,
                                                    params,
                                                    ordinal) :
        shared_mem = self._spec.sharedMemoryType(key=params['key'], 
                                                  shmflg=params['flags'], 
                                                  size=params['size'], 
                                                  order=ordinal, 
                                                  inputID=params['id'],
                                                  value=self._build_value_with_type(params))
        return shared_mem
        
    def _build_input_parameter_script_input(self,
                                             params,
                                             ordinal) :
        script = self._spec.scriptType(name=params['name'],
                                        order=ordinal, 
                                        inputID=params['id'])
        return script
    
    def _build_output_group(self,
                            params) :
        child_outputs = None
        child_groups = None
        
        if params['groups'] is not None and\
                len(params['groups']) > 0 :
            child_groups = [ ]
            for item in params['groups'] :
                child_groups.append(self._build_output_group(item))
        
        if params['outputs'] is not None and\
                len(params['outputs']) > 0 :
            child_outputs = [ ]
            for item in params['outputs'] :
                child_outputs.append(self._build_output_parameter(item))
        
        output = self._spec.outputGroupType(operator=self._enum_output_operators.\
                marshall(params['operator']),
            io_outputs=self._spec.ioOutputsType(io_output=child_outputs))
        
        if child_groups is not None :
            output.set_output_groups(self._spec.outputGroupsType(output_group=child_groups))
        
        return output
    
    def _build_output_parameter(self,
                                 params) :
        
        return self._spec.ioOutputType(\
            inputIDREF=params['input'],
            value_check_type=self._enum_output_value_check_types.marshall(params['check']),
            output_type=self._enum_output_types.marshall(params['source']),
            value=self._build_value_with_type(params))

class StewIOPair2_1_1(StewIOPair2_1_0) :
    def __init__(self, *args, **kwargs):
        super(StewIOPair2_1_1, self).__init__(*args, **kwargs)
    
    def _build_new(self, **kwargs) :
        return StewIOPair2_1_1(**kwargs)
    
    def _build_output_parameter(self,
                                 params) :
        return self._spec.ioOutputType(\
            inputIDREF=params['input'],
            target_output_path=params['target_file'],
            value_check_type=self._enum_output_value_check_types.marshall(params['check']),
            output_type=self._enum_output_types.marshall(params['source']),
            value=self._build_value_with_type(params))
    
    def add_output_parameter(self,
                             parent=None,
                             **kwargs) :
                             
        source = kwargs.get('source', None)
        input = kwargs.get('input', None)
        check = kwargs.get('check', 'equals')
        target_file = kwargs.get('target_file', None)
        
        if source is None :
            raise ValueError('output source not specified.')
        
        if not self._enum_output_types.is_valid(source) : 
            raise ValueError('output source not supported.')
        if not self._enum_output_value_check_types.is_valid(check) : 
            raise ValueError('output check type not supported.')
        
        parameter = { 'type': 'output',
                      'source': self._enum_output_types.marshall(source),
                      'input': input,
                      'check': self._enum_output_value_check_types.marshall(check),
                      'target_file': target_file }
        parameter.update(self._extract_input_parameter_value_with_type(**kwargs))
        
        if parameter['source'] == 'file_contents' and\
                target_file is None :
            raise ValueError('target file not specified.')
        
        if parent is None :
            # add a default group container
            parent = self.add_output_parameter_group(operator=kwargs.get('operator', None))
        else :
            if 'type' not in parent :
                raise ValueError('Invalid parent provided.')
            if parent['type'] != 'output_group' :
                raise ValueError('Invalid parent type provided.  Expected an \'output_group\'.')
        
        parent['outputs'].append(parameter)
        
        return parent
    
    def _load_output_item(self,
                          element) :
        parameter = super(StewIOPair2_1_1, self)._load_output_item(element)
        
        if parameter is None :
            return None
        
        parameter['target_file'] = element.get_target_output_path()
                
        return parameter